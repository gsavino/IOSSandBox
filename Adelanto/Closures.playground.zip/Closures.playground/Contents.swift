//: Playground - noun: a place where people can play

import UIKit

func saludar() {
    var str = "Hello, playground"
    print(str)
}

func sumar(a: Int, b: Int) -> Int {
    return a + b
}

func multiplicar(unNumero: Int, otroNumero: Int) -> Int {
    return unNumero * otroNumero
}

// variables implicitas
var nombre = "pepe"

var comportamiento = saludar
var operacion = multiplicar

// variables explicitas
var apellido : String
apellido = "perez"

var comportamiento2: (  () -> Void  )
comportamiento2 = saludar

var operacion2: (  (Int, Int) -> Int  )
operacion2 = sumar
operacion2 = operacion

//operacion2 = comportamiento >> NO SE PUEDE


// FUNCIONES ANONIMAS

// esto (definicion INLINE o ANONIMA en otros lenguajes):
var toser = {
    print("cof cof")
}

// es equivalente a:
func x() {
    print("cof cof")
}
var toser2 = x
// fin


// 'toser' es una funcion!
// si la quiero ejecutar, le pongo los parentesis al final
toser()

// lo mismo con 'toser2'
toser2()


// FUNCIONES ANONIMAS CON PARAMETROS

func gritarF(mensaje: String) {
    print(mensaje)
}

// definicion implicita
//var gritar = { mensaje in
//    print(mensaje)
//}

// definicion explicita
var gritar: ( (String) -> Void ) = { mensaje in
    print(mensaje)
}

gritarF(mensaje: "HOLA MUNDO")
gritarF(mensaje: 7)

//gritar(7)      > Solo funciona si el closure es implicito (recibe ANY)
//gritar(true)   > Solo funciona si el closure es implicito (recibe ANY)
//gritar(Date()) > Solo funciona si el closure es implicito (recibe ANY)
gritar("HOLA")








