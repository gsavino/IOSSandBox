//
//  ViewController.swift
//  PrimerLibreria
//
//  Created by Andres Ciaño on 07/05/2018.
//  Copyright © 2018 Digital House. All rights reserved.
//

import UIKit
import Kingfisher

class ViewController: UIViewController {

    @IBOutlet weak var theImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        // CREO UN OBJETO URL A PARTIR DE UN STRING
        let url = URL(string: "https://upload.wikimedia.org/wikipedia/commons/9/97/The_Earth_seen_from_Apollo_17.jpg")

        // SETEO LA IMAGEN A PARTIR DE LA URL USANDO KINGFISHER
        // theImageView.kf.setImage(with: url)

        // FUNCIONALIDAD MAS AVANZADA, MOSTRANDO UN PLACEHOLDER MIENTRAS SE
        // DESCARGA LA IMAGEN QUE QUIERO MOSTRAR
        theImageView.kf.setImage(with: url, placeholder: UIImage(named: "placeholder"), options: nil, progressBlock: nil, completionHandler: nil)


        // ANIMACIONES:

        // Normalente, la funcion que mueve al imageview la ejecutaria
        // animacionDeLaImagen()

        // pero la queremos animar -> usamos animateWithDuration
        // el closure que quiero ejecutar para hacer animacion
        // es la funcion que tengo definida SIN LOS PARENTESIS
         UIView.animate(withDuration: 3, animations: animacionDeLaImagen)

        // alternativamente, si no tengo una funcion definida
        // puedo definir un closure (funcion anonima):
        UIView.animate(withDuration: 3) {
            self.theImageView.center.y += 100
        }
        // el paramentro 'animations' desaparece porque el closure es el ultimo
        // parametro requerido por la funcion, entonces automaticamente
        // se indican las llaves de la funcion anonima por fuera de los parentesis
        // lo anterior es lo mismo que hacer:
        UIView.animate(withDuration: 3, animations: {
            self.theImageView.center.y += 100
        })


        // se pueden poner muchos closures en la misma llamada
        // y cambia la firma si se reciben parametros
        UIView.animate(withDuration: 3, animations: {
            self.theImageView.center.y += 100
        }) { (resultado) in
            print("el resultado de la animacion fue \(resultado)")
        }

    }


    func animacionDeLaImagen() {
        theImageView.center.y += 100
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

